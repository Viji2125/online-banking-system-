package com.vdr.app.mappers;

import com.vdr.app.dto.out.CreditStatusOut;
import com.vdr.app.models.enums.CreditStatus;

import org.mapstruct.Mapper;

@Mapper (componentModel = "spring")
public interface CreditStatusMapper
{
        CreditStatusOut entityToDTO ( CreditStatus creditStatus );
}
