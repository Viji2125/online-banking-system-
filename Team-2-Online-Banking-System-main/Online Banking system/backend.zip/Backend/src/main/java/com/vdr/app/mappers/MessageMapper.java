package com.vdr.app.mappers;

import com.vdr.app.dto.in.ConversationIn;
import com.vdr.app.dto.in.MessageIn;
import com.vdr.app.dto.out.ConversationOut;
import com.vdr.app.dto.out.MessageOut;
import com.vdr.app.models.Conversation;
import com.vdr.app.models.Message;

import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface MessageMapper {
    Message DTOtoEntity(MessageIn messageIn);

    MessageOut entityToDTO(Message message);
}
