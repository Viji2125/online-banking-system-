package com.vdr.app.repositories;

import com.vdr.app.models.Conversation;
import com.vdr.app.models.enums.ConversationDirection;
import com.vdr.app.models.user.User;

import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ConversationRepository extends JpaRepository<Conversation, Long> {
    List<Conversation> findAllByConversationDirection(ConversationDirection conversationDirection);

    List<Conversation> findAllByUser(User user);
}