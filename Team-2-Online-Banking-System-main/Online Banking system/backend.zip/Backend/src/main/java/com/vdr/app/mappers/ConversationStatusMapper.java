package com.vdr.app.mappers;

import com.vdr.app.dto.out.BankAccTypeOut;
import com.vdr.app.dto.out.ConversationStatusOut;
import com.vdr.app.models.BankAccType;
import com.vdr.app.models.enums.ConversationStatus;

import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface ConversationStatusMapper {
    ConversationStatusOut entityToDto(ConversationStatus conversationStatus);
}
