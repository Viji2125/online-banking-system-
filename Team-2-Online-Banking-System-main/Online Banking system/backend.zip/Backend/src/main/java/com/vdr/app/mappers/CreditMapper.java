package com.vdr.app.mappers;

import com.vdr.app.dto.in.CreditIn;
import com.vdr.app.dto.out.CreditOut;
import com.vdr.app.models.Credit;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring", uses = CreditStatusMapper.class)
public interface CreditMapper {
    Credit DTOtoEntity(CreditIn creditIn);

    @Mapping(source = "credit.destinedSaldo.id", target = "destinedSaldoId")
    CreditOut entityToDTO(Credit credit);
}
