package com.vdr.app.mappers;

import com.vdr.app.dto.edit.AddressEdit;
import com.vdr.app.dto.in.AddressIn;
import com.vdr.app.dto.out.AddressOut;
import com.vdr.app.models.user.Address;

import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface AddressMapper {
    Address DTOtoEntity(AddressIn addressIn);

    AddressOut entityToDTO(Address address);
}
