package com.vdr.app.services.interfaces;

import com.vdr.app.dto.edit.AddressEdit;
import com.vdr.app.dto.out.AddressOut;

public interface AddressService
{
        AddressOut update (Long id, AddressEdit addressEdit);
}
