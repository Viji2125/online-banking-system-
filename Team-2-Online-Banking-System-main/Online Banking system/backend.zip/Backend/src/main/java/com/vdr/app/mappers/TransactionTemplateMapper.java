package com.vdr.app.mappers;

import com.vdr.app.dto.in.TransactionTemplateIn;
import com.vdr.app.dto.out.TransactionTemplateOut;
import com.vdr.app.models.TransactionTemplate;

import org.mapstruct.Mapper;

@Mapper (componentModel = "spring")
public interface TransactionTemplateMapper
{
        TransactionTemplateOut entityToDTO ( TransactionTemplate transactionTemplate );

        TransactionTemplate DTOtoEntity ( TransactionTemplateIn transactionTemplateIn );
}
