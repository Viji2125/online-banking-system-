package com.vdr.app.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.vdr.app.models.Installment;

import java.util.List;

public interface InstallmentRepository extends JpaRepository<Installment, Long> {
    List<Installment> findAllByCredit_Id(Long id);
}
