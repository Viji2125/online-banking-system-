package com.vdr.app.services.interfaces;

import com.vdr.app.dto.in.ExchangeCurrencyIn;
import com.vdr.app.dto.out.ExchangeCurrencyOut;

import java.math.BigDecimal;

public interface ExchangeCurrencyService
{
        ExchangeCurrencyOut create ( ExchangeCurrencyIn exchangeCurrencyIn );

        BigDecimal calculate(ExchangeCurrencyIn exchangeCurrencyIn);
}
