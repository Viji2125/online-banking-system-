package com.vdr.app.services.interfaces;

import com.vdr.app.dto.in.PaymentIn;
import com.vdr.app.dto.out.PaymentOut;

import java.util.List;

public interface PaymentService {
    PaymentOut create(PaymentIn paymentIn);

    List<PaymentOut> findAllByBankAccountId(Long bankAccountId);

    List<PaymentOut> findAll();
}
