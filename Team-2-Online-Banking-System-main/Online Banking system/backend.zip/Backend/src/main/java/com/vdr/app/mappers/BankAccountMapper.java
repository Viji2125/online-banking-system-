package com.vdr.app.mappers;

import com.vdr.app.dto.out.BankAccountOut;
import com.vdr.app.models.BankAccType;
import com.vdr.app.models.BankAccount;

import org.mapstruct.Mapper;

@Mapper(componentModel = "spring", uses = {SaldoMapper.class, BankAccTypeMapper.class})
public interface BankAccountMapper {
    BankAccountOut entityToDTO(BankAccount bankAccount);
}
