package com.vdr.app.models.enums;

/*public enum Currency
{
        INR, // zlotowki
        USD, // dolar amerykanski
        EUR, // euro
        CHF, // frank szwajcarski
        GBP // funt szterling
}
*/