package com.vdr.app.services.interfaces;

public interface EmailService {
    void sendRegisterMail(String receiver, String identifier);
}
