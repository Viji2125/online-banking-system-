package com.vdr.app.services.interfaces;

import java.util.List;

import com.vdr.app.dto.out.InvestmentTypeOut;

public interface InvestmentTypeService {
    List<InvestmentTypeOut> findAll();
}
