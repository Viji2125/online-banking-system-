package com.vdr.app.models;
// id_transakcji (generowac na froncie), kilkunakowy token
public class TransactionCode
{
}
