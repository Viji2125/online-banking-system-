package com.vdr.app.services.interfaces;

import com.vdr.app.dto.in.InvestmentIn;
import com.vdr.app.dto.out.InvestmentOut;

import java.util.List;

public interface InvestmentService {
    List<InvestmentOut> findAll();

    List<InvestmentOut> findAllByUser();

    InvestmentOut findById(Long id);

    Long findInvestmentCountByType(Long id);

    InvestmentOut updateStatus(Long id);

    InvestmentOut create(InvestmentIn investment);

    List<InvestmentOut> findActiveByBankAccountId(Long bankAccountId);

}