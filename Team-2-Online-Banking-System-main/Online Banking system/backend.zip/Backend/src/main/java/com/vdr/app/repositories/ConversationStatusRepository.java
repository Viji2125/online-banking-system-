package com.vdr.app.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.vdr.app.models.enums.ConversationStatus;

public interface ConversationStatusRepository extends JpaRepository<ConversationStatus, Long> {
    ConversationStatus findByConversationType(ConversationStatus.ConversationType conversationType);
}
