package com.vdr.app.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.vdr.app.models.TransactionTemplate;

import java.util.List;

public interface TransactionTemplateRepository extends JpaRepository<TransactionTemplate, Long> {

    List<TransactionTemplate> findAllByUser_Identifier(String identifier);
}
