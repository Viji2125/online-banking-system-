package com.vdr.app.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.vdr.app.models.enums.CreditStatus;

public interface CreditStatusRepository extends JpaRepository<CreditStatus, Long> {
    CreditStatus findByCreditType(CreditStatus.CreditType creditType);

}
