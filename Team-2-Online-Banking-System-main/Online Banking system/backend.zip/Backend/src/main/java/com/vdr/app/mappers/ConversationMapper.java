package com.vdr.app.mappers;

import com.vdr.app.dto.in.ConversationIn;
import com.vdr.app.dto.out.ConversationOut;
import com.vdr.app.models.Conversation;

import org.mapstruct.Mapper;

@Mapper(componentModel = "spring", uses={ConversationDirectionMapper.class, ConversationStatusMapper.class})
    public interface ConversationMapper {
    Conversation DTOtoEntity (ConversationIn conversationIn );
    ConversationOut entityToDTO (Conversation conversation );
}
