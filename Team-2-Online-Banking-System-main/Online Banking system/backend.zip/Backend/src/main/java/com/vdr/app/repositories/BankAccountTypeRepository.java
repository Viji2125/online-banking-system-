package com.vdr.app.repositories;

import com.vdr.app.models.BankAccType;
import com.vdr.app.models.enums.BankAccountType;

import org.springframework.data.jpa.repository.JpaRepository;

public interface BankAccountTypeRepository extends JpaRepository<BankAccType, Long> {
    BankAccType findByBankAccountType(BankAccountType bankAccountType);
}
