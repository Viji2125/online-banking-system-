package com.vdr.app.services.interfaces;

import com.vdr.app.dto.in.InstallmentIn;
import com.vdr.app.dto.out.InstallmentOut;

import java.util.List;

public interface InstallmentService {
    InstallmentOut create(InstallmentIn installmentIn);

    List<InstallmentOut> findAllByCreditId(Long id);
}
