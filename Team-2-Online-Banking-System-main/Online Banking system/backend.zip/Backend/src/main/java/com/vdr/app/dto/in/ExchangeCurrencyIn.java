package com.vdr.app.dto.in;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.validator.constraints.Length;

import com.vdr.app.models.BankAccount;
import com.vdr.app.models.CurrencyType;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Positive;

@NoArgsConstructor
@AllArgsConstructor
@Data
public class ExchangeCurrencyIn {

    @Positive
    private float balance;

    @NotEmpty
    private String sourceBankAccNumber;

    @NotEmpty
    private String sourceCurrency;

    @NotEmpty
    private String destCurrency;
}
