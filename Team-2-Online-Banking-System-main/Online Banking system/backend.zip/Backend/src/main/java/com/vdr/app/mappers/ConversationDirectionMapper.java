package com.vdr.app.mappers;

import com.vdr.app.dto.out.ConversationOut;
import com.vdr.app.models.enums.ConversationDirection;

import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface ConversationDirectionMapper {
    ConversationOut entityToDTO (ConversationDirection conversationDirection );
}
