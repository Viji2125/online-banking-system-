package com.vdr.app.services.interfaces;

import com.vdr.app.dto.in.TransactionTemplateIn;
import com.vdr.app.dto.out.TransactionTemplateOut;

import java.util.List;

public interface TransactionTemplateService {
    TransactionTemplateOut create(TransactionTemplateIn transactionTemplateIn);

    List<TransactionTemplateOut> findAll();

    TransactionTemplateOut findOneById(Long id);

    TransactionTemplateOut update(Long id, TransactionTemplateIn transactionTemplateIn);

    void deleteById(Long id);

    List<TransactionTemplateOut> findAllByCurrentUser();

}
