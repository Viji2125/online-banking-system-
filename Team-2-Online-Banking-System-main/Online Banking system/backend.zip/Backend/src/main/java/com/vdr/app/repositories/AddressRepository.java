package com.vdr.app.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.vdr.app.models.user.Address;

public interface AddressRepository extends JpaRepository<Address, Long>
{
}
