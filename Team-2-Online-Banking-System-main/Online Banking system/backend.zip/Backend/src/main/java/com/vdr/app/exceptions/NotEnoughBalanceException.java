package com.vdr.app.exceptions;

public class NotEnoughBalanceException
{
}
