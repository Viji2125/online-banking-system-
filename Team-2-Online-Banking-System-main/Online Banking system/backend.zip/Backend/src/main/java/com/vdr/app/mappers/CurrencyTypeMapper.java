package com.vdr.app.mappers;

import com.vdr.app.dto.in.CurrencyTypeIn;
import com.vdr.app.dto.out.CurrencyTypeOut;
import com.vdr.app.models.CurrencyType;

import org.mapstruct.Mapper;

@Mapper (componentModel = "spring")
public interface CurrencyTypeMapper
{
        CurrencyType DTOtoEntity ( CurrencyTypeIn currencyTypeIn );

        CurrencyTypeOut entityToDTO ( CurrencyType currencyType );
}