package com.vdr.app.dto.in;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.validator.constraints.Length;

import com.vdr.app.models.enums.ConversationDirection;
import com.vdr.app.models.enums.ConversationStatus;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ConversationIn {
    private Long id;

    @NotEmpty
    @Length(min = 1, max = 255)
    private String topic;

    @NotEmpty
    @Length(min = 1, max = 255)
    private String description;

    @NotNull
    private ConversationStatus.ConversationType conversationType;

    @NotNull
    private ConversationDirection.ConversationDirectionType conversationDirectionType;
}
