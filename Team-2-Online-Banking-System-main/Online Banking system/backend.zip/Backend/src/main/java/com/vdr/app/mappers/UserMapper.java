package com.vdr.app.mappers;

import com.vdr.app.dto.in.UserIn;
import com.vdr.app.dto.out.UserOut;
import com.vdr.app.models.user.User;

import org.mapstruct.Mapper;

@Mapper(componentModel = "spring", uses = AddressMapper.class)
public interface UserMapper {
    User userInToUser(UserIn userIn);
    UserOut userToUserOut(User user);
}
