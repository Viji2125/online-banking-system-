package com.vdr.app.mappers;

import com.vdr.app.dto.out.PaymentOut;
import com.vdr.app.models.Payment;

import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface PaymentMapper {
    PaymentOut entityToDto(Payment payment);
}
