package com.vdr.app.mappers;

import com.vdr.app.dto.in.InstallmentIn;
import com.vdr.app.dto.out.InstallmentOut;
import com.vdr.app.models.Installment;

import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface InstallmentMapper {
    Installment dtoToEntity(InstallmentIn installmentIn);

    InstallmentOut entityToDto(Installment installment);
}
