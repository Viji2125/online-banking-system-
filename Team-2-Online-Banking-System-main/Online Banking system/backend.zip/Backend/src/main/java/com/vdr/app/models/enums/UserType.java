package com.vdr.app.models.enums;

public class UserType
{
}
