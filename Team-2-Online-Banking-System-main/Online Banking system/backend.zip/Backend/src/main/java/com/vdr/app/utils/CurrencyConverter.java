package com.vdr.app.utils;

import java.math.BigDecimal;

import com.vdr.app.models.CurrencyType;

public interface CurrencyConverter
{
        BigDecimal convertCurrency ( float currency, CurrencyType sourceCurrency, CurrencyType destinedCurrency );
}
