package com.vdr.app.mappers;

import com.vdr.app.dto.out.BankAccTypeOut;
import com.vdr.app.models.BankAccType;

import org.mapstruct.Mapper;

@Mapper (componentModel = "spring")
public interface BankAccTypeMapper
{
        BankAccTypeOut entityToDto ( BankAccType bankAccType );
}
