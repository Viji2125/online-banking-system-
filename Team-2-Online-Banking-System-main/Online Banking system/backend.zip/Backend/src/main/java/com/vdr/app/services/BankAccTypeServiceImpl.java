package com.vdr.app.services;

import com.vdr.app.dto.edit.BankAccTypeEdit;
import com.vdr.app.dto.out.BankAccTypeOut;
import com.vdr.app.exceptions.ApiException;
import com.vdr.app.mappers.BankAccTypeMapper;
import com.vdr.app.mappers.BankAccountMapper;
import com.vdr.app.models.BankAccType;
import com.vdr.app.repositories.BankAccountTypeRepository;
import com.vdr.app.services.interfaces.BankAccTypeService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class BankAccTypeServiceImpl implements BankAccTypeService {
    private final BankAccountTypeRepository bankAccountTypeRepository;

    private final BankAccTypeMapper bankAccTypeMapper;

    @Autowired
    public BankAccTypeServiceImpl(BankAccountTypeRepository bankAccountTypeRepository,
                                  BankAccTypeMapper bankAccTypeMapper) {
        this.bankAccountTypeRepository = bankAccountTypeRepository;
        this.bankAccTypeMapper = bankAccTypeMapper;
    }

    @Override
    public List<BankAccTypeOut> findAll() {
        return bankAccountTypeRepository.findAll()
            .stream()
            .map(bankAccTypeMapper::entityToDto)
            .collect(Collectors.toList());
    }

    @Override
    public BankAccTypeOut update(Long id, BankAccTypeEdit bankAccTypeEdit) {
        BankAccType bankAccType = bankAccountTypeRepository.findById(id)
            .orElseThrow(() -> new ApiException("Exception.notFound", null));

        bankAccType.setExchangeCurrencyCommission(bankAccTypeEdit.getExchangeCurrencyCommission().floatValue());
        bankAccType.setTransactionComission(bankAccTypeEdit.getTransactionComission().floatValue());

        return bankAccTypeMapper.entityToDto(bankAccountTypeRepository.save(bankAccType));
    }

    @Override
    public BankAccTypeOut findById(Long id) {
        return bankAccTypeMapper.entityToDto(
            bankAccountTypeRepository.findById(id).orElseThrow(() -> new ApiException("Exception.notFound", null))
        );
    }
}
