package com.vdr.app.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.vdr.app.models.Saldo;

public interface SaldoRepository extends JpaRepository<Saldo, Long> {

}
