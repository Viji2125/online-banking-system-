package com.vdr.app.services.interfaces;

import com.vdr.app.dto.edit.CurrencyTypeEdit;
import com.vdr.app.dto.in.CurrencyTypeIn;
import com.vdr.app.dto.out.CurrencyTypeOut;

import java.util.List;

public interface CurrencyTypeService {
    List<CurrencyTypeOut> findAll();

    CurrencyTypeOut create(CurrencyTypeIn currencyTypeIn);

    CurrencyTypeOut update(Long id, CurrencyTypeEdit currencyTypeEdit);

    CurrencyTypeOut findById(Long id);
}
