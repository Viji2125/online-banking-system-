package com.vdr.app.models.enums;

public enum BankAccountType
{
        MULTI_CURRENCY,
        STANDARD,
        STUDENT
}

