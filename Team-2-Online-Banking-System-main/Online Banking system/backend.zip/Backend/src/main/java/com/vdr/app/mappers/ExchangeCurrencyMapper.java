package com.vdr.app.mappers;

import com.vdr.app.dto.in.ExchangeCurrencyIn;
import com.vdr.app.dto.out.ExchangeCurrencyOut;
import com.vdr.app.models.ExchangeCurrency;

import org.mapstruct.Mapper;

@Mapper (componentModel = "spring")
public interface ExchangeCurrencyMapper
{
        ExchangeCurrency DTOtoEntity ( ExchangeCurrencyIn exchangeCurrencyIn );

        ExchangeCurrencyOut entityToDTO ( ExchangeCurrency exchangeCurrency );
}
