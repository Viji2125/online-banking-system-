package com.vdr.app.mappers;

import com.vdr.app.dto.in.TransactionIn;
import com.vdr.app.dto.out.TransactionOut;
import com.vdr.app.models.Transaction;

import org.mapstruct.Mapper;

@Mapper(componentModel = "spring", uses = BankAccountMapper.class)
public interface TransactionMapper {
    TransactionOut entityToDTO(Transaction transaction);
}
