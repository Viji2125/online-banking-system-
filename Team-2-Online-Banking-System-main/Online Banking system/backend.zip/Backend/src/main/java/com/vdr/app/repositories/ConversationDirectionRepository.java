package com.vdr.app.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.vdr.app.models.enums.ConversationDirection;

public interface ConversationDirectionRepository extends JpaRepository<ConversationDirection, Long> {
    ConversationDirection findByConversationDirectionType(ConversationDirection.ConversationDirectionType conversationDirectionType);
}
