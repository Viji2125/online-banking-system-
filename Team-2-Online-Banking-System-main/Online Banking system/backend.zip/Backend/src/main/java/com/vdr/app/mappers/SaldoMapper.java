package com.vdr.app.mappers;

import com.vdr.app.dto.out.SaldoOut;
import com.vdr.app.models.Saldo;

import org.mapstruct.Mapper;

@Mapper (componentModel = "spring", uses=CurrencyTypeMapper.class)
public interface SaldoMapper
{
        SaldoOut saldoToSaldoOut( Saldo saldo);
}
