import { RegisterFormValidator } from './register-form-validator';

describe('RegisterFormValidator', () => {
  it('should create an instance', () => {
    expect(new RegisterFormValidator()).toBeTruthy();
  });
});
