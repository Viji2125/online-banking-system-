import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-template-create',
  templateUrl: './template-create.component.html',
  styleUrls: ['./template-create.component.scss']
})
export class TemplateCreateComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
