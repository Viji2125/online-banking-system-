import { BankAccountNumberValidator } from './bank-account-number-validator';

describe('BankAccountNumberValidator', () => {
  it('should create an instance', () => {
    expect(new BankAccountNumberValidator()).toBeTruthy();
  });
});
