import { InvestmentType } from './investment-type';

describe('InvestmentType', () => {
  it('should create an instance', () => {
    expect(new InvestmentType()).toBeTruthy();
  });
});
