import { BankAccType } from './bank-acc-type';

describe('BankAccType', () => {
  it('should create an instance', () => {
    expect(new BankAccType()).toBeTruthy();
  });
});
