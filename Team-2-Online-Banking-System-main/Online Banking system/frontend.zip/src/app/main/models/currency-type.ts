export class CurrencyType {
    id: number;
    exchangeRate: number;
    name: string;
}
