import { CurrencyType } from './currency-type';

describe('CurrencyType', () => {
  it('should create an instance', () => {
    expect(new CurrencyType()).toBeTruthy();
  });
});
