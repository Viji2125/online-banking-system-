export class BankAccType {
    id: number;
    bankAccountType: string;
    transactionComission: number;
    exchangeCurrencyCommission: number;
    name: string;
}
