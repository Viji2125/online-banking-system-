import { CurrencyType } from './currency-type';

export class Saldo {
    id: number;
    currencyType: CurrencyType;
    balance: number;
}
