export class Installment {
    id: number;
    payDate: Date;
    amount: number;
}
