import { Credit } from './credit';

describe('Credit', () => {
  it('should create an instance', () => {
    expect(new Credit()).toBeTruthy();
  });
});
