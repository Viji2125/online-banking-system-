export class ExchangeCurrency {
    balance: number;
    sourceBankAccNumber: string;
    sourceCurrency: string;
    destCurrency: string;
}
