import { Conversation } from './conversation';

describe('Conversation', () => {
  it('should create an instance', () => {
    expect(new Conversation()).toBeTruthy();
  });
});
