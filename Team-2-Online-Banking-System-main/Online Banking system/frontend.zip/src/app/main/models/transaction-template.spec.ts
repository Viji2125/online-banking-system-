import { TransactionTemplate } from './transaction-template';

describe('TransactionTemplate', () => {
  it('should create an instance', () => {
    expect(new TransactionTemplate()).toBeTruthy();
  });
});
