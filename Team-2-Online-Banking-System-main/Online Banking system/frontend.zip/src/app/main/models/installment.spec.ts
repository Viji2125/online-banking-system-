import { Installment } from './installment';

describe('Installment', () => {
  it('should create an instance', () => {
    expect(new Installment()).toBeTruthy();
  });
});
