export class InvestmentType {
    id: number;
    investmentStatus: string;
}
