import { Saldo } from './saldo';

describe('Saldo', () => {
  it('should create an instance', () => {
    expect(new Saldo()).toBeTruthy();
  });
});
