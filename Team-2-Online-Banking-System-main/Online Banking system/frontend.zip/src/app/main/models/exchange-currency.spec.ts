import { ExchangeCurrency } from './exchange-currency';

describe('ExchangeCurrency', () => {
  it('should create an instance', () => {
    expect(new ExchangeCurrency()).toBeTruthy();
  });
});
